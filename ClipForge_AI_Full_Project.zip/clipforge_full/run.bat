@echo off
cd /d %~dp0
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
where ffmpeg >nul 2>nul
if errorlevel 1 (
 echo FFmpeg is required. Install FFmpeg and add it to PATH, then run this file again.
 pause
 exit /b 1
)
if not exist .env copy .env.example .env
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
